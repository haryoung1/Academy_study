package quiz_Interfaces;

public class JobLec implements JobImpl {

	@Override
	public void job() {
		System.out.println("���Ǹ� �մϴ�.");

	}

}
