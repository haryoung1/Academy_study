package quiz_Interfaces;

public interface JobImpl {
	public void job();
}
