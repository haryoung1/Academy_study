package quiz_Interfaces;

public interface GetImpl {
	public void get();
}
