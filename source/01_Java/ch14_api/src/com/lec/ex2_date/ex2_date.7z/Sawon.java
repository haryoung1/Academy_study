package com.lec.ex2_date;

import java.text.SimpleDateFormat;
import java.util.GregorianCalendar;
import java.util.Calendar;
import java.util.Date;

public class Sawon {
	
	private String no;
	private String name;
	private String part;
	
	private Date date;

	public Sawon() {
	}

	public Sawon(String no, String name, String part) {
		this.no = no;
		this.name = name;
		this.part = part;
		date = new Date();
	}

	public Sawon(String no, String name, String part, int year, int month, int day) {
		this.no = no;
		this.name = name;
		this.part = part;
		date = new Date (new GregorianCalendar(year,month-1,day).getTimeInMillis());
	}

	@Override
	public String toString() {
		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy.MM.dd");
		return "[���]" + no + " \t[�̸�]" + name + "\t[�μ�]" + part + "\t[�Ի���]" + sdf1.format(date);
	}

	public String getNo() {
		return no;
	}

	public String getName() {
		return name;
	}

	public String getPart() {
		return part;
	}
}