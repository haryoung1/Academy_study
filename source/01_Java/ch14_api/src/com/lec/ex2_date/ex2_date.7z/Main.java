package com.lec.ex2_date;


public class Main {
	public static void main(String[] args) {
		Sawon[] sawons = {new Sawon("A01", "ȫ�浿", "COMPUTER"),
						  new Sawon("A02", "��浿", "PLANNING"),
						  new Sawon("B01", "���ͼ�",  "DESIGN",2022,01,14),
						  new Sawon("B02", "���ﱹ","COMPUTER",2022,12,12),};
		for (Sawon sawon : sawons) {
		System.out.println(sawon);
		}
	}
}
