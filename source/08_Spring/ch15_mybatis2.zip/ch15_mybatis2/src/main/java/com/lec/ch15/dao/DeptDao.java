package com.lec.ch15.dao;

import java.util.List;

import com.lec.ch15.model.Dept;

public interface DeptDao {
	public List<Dept> deptList();

}
